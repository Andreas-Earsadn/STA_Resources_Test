import 'package:flutter/material.dart';
import 'package:untitled1/SQLLite/sql_lite.dart';
import 'package:untitled1/models/karyawan_model.dart';
class Form2 extends StatefulWidget {


  @override
  _Form2State createState() => _Form2State();
}

class _Form2State extends State<Form2> {
  TextEditingController _namaController = TextEditingController();
  TextEditingController _tglMasukKerjaController = TextEditingController();
  TextEditingController _usiaController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Form 2'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            TextField(
              controller: _namaController,
              decoration: InputDecoration(labelText: 'Nama'),
            ),
            SizedBox(height: 16),
            TextField(
              controller: _tglMasukKerjaController,
              decoration: InputDecoration(labelText: 'Tgl Masuk Kerja'),
            ),
            SizedBox(height: 16),
            TextField(
              controller: _usiaController,
              keyboardType: TextInputType.number,
              decoration: InputDecoration(labelText: 'Usia'),
            ),
            SizedBox(height: 16),
            ElevatedButton(
              onPressed: () async {
                Karyawan karyawan = Karyawan(
                  nama: _namaController.text,
                  tglMasukKerja: _tglMasukKerjaController.text,
                  usia: int.tryParse(_usiaController.text) ?? 0,
                );

                await DatabaseHelper.instance.insert(karyawan);

                Navigator.pop(context);
              },
              child: Text('Save'),
            ),
          ],
        ),
      ),
    );
  }
}
