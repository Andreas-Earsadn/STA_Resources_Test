import 'package:flutter/material.dart';
import 'package:untitled1/SQLLite/sql_lite.dart';
import 'package:untitled1/models/karyawan_model.dart';
import 'package:untitled1/screens/form2.dart';

class Form1 extends StatefulWidget {
  @override
  _Form1State createState() => _Form1State();
}

class _Form1State extends State<Form1> {
  TextEditingController _searchController = TextEditingController();
  List<Karyawan>? _filteredData = [];
  List<Karyawan>? _allData = [];

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  _loadData() async {
    List<Karyawan>? data = await DatabaseHelper.instance.queryAllRows();
    setState(() {
      _allData = data;
      _filteredData = data;
    });
  }

  _searchData(String query) {
    List<Karyawan> result = _allData!
        .where((karyawan) =>
    karyawan.nama!.toLowerCase().contains(query.toLowerCase()) ||
        karyawan.usia.toString().contains(query) ||
        karyawan.tglMasukKerja!
            .toLowerCase()
            .contains(query.toLowerCase()))
        .toList();

    setState(() {
      _filteredData = result;
    });
  }

  _deleteData(int? id) async {
    await DatabaseHelper.instance.delete(id!);
    _loadData(); // Refresh data setelah menghapus
  }

  _showForm2() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => Form2(),
      ),
    ).then((value) {
      // Ketika Form2 ditutup, refresh data di Form1
      _loadData();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Form 1'),
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(8.0),
            child:
            TextField(
              controller: _searchController,
              onChanged: _searchData,
              decoration: InputDecoration(
                hintText: 'Cari berdasarkan nama, usia, atau tgl masuk kerja',

                contentPadding: EdgeInsets.symmetric(horizontal: 16),
                border: OutlineInputBorder(),
                suffixIcon: IconButton(
                  icon: Icon(Icons.clear),
                  onPressed: () {
                    _searchController.clear();
                    _searchData('');
                  },
                ),
              ),
            ),
          ),
          Expanded(
            child: _filteredData != null
                ? SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: DataTable(
                columns: [

                  DataColumn(label: Text('Actions')),
                  DataColumn(label: Text('ID')),
                  DataColumn(label: Text('Nama')),
                  DataColumn(label: Text('Tgl Masuk \n Kerja')),
                  DataColumn(label: Text('Usia')),
                ],
                rows: _filteredData!.map((karyawan) {
                  return DataRow(
                    cells: [
                      DataCell(
                        Row(
                          children: [
                            IconButton(
                              icon: Icon(Icons.delete),
                              onPressed: () {
                                _deleteData(karyawan.id);
                              },
                            ),
                            IconButton(
                              icon: Icon(Icons.edit),
                              onPressed: () {
                                // _editData(karyawan.id);
                              },
                            ),
                          ],
                        ),
                      ),
                      DataCell(Text(karyawan.id.toString())),
                      DataCell(
                        Container(
                          width: 100, // Set the maximum width
                          child: Text(
                            karyawan.nama!,
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                      ),
                      DataCell(Text(karyawan.tglMasukKerja.toString())),
                      DataCell(Text(karyawan.usia.toString())),

                    ],
                    onSelectChanged: (selected) {
                      // Implementasi edit data
                    },
                  );
                }).toList(),
              ),
            )
                : Center(
              child: CircularProgressIndicator(),
            ),
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              ElevatedButton(
                onPressed: _showForm2,
                child: Text('New'),
              ),
              ElevatedButton(
                onPressed: () {
                  // Implementasi delete data di sini
                },
                child: Text('Delete'),
              ),
              ElevatedButton(
                onPressed: () {
                  // Implementasi close aplikasi di sini
                },
                child: Text('Close'),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
