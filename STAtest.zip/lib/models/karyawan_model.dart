class Karyawan {
  int? id;
  String? nama;
  String? tglMasukKerja;
  int? usia;

  Karyawan({this.id, this.nama, this.tglMasukKerja, this.usia});

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'nama': nama,
      'tglMasukKerja': tglMasukKerja,
      'usia': usia,
    };
  }
  factory Karyawan.fromMap(Map<String, dynamic> map) {
    return Karyawan(
      id: map['id'],
      nama: map['nama'],
      tglMasukKerja: map['tglMasukKerja'],
      usia: map['usia'],
    );
  }
}
