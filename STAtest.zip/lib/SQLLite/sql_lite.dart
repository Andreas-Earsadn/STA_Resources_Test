import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';
import 'package:untitled1/models/karyawan_model.dart';

class DatabaseHelper {
  static final _databaseName = 'karyawan.db';
  static final _databaseVersion = 1;

  static final table = 'karyawan';

  static final columnId = 'id';
  static final columnNama = 'nama';
  static final columnTglMasukKerja = 'tglMasukKerja';
  static final columnUsia = 'usia';

  DatabaseHelper._privateConstructor();
  static final DatabaseHelper instance = DatabaseHelper._privateConstructor();

  static Database? _database;
  Future<Database?> get database async {
    if (_database != null) return _database;

    _database = await _initDatabase();
    return _database;
  }

  Future<Database> _initDatabase() async {
    String path = join(await getDatabasesPath(), _databaseName);
    return await openDatabase(
      path,
      version: _databaseVersion,
      onCreate: _onCreate,
    );
  }

  Future<void> _onCreate(Database db, int version) async {
    await db.execute('''
      CREATE TABLE $table (
        $columnId INTEGER PRIMARY KEY,
        $columnNama TEXT,
        $columnTglMasukKerja TEXT,
        $columnUsia INTEGER
      )
    ''');
  }

  Future<int?> insert(Karyawan? karyawan) async {
    Database? db = await instance.database!;
    return await db?.insert(table, karyawan!.toMap());
  }


  Future<List<Karyawan>> queryAllRows() async {
    Database? db = await instance.database;
    var result = await db?.query(table);
    return result?.map((e) => Karyawan.fromMap(e)).toList() ?? [];
  }

  Future<int?> update(Karyawan? karyawan) async {
    Database? db = await instance.database!;
    return await db?.update(
      table,
      karyawan!.toMap(),
      where: '$columnId = ?',
      whereArgs: [karyawan.id],
    );
  }

  Future<int?> delete(int id) async {
    Database? db = await instance.database!;
    return await db?.delete(
      table,
      where: '$columnId = ?',
      whereArgs: [id],
    );
  }
}
